1. Run all commands in "set_runpod_conda.sh"
2. Restart terminal
3. Run all commands in "set_runpod_env.sh", edit last two commands to accomodate your git account
4. Run all commands in "activate_gpu_env.sh"